//
//  AppDelegate.swift
//  Balot
//
//  Created by Yasser Alanazi on 25/08/2018.
//  Copyright © 2018 Yasser Alanazi. All rights reserved.
//
import UIKit

class cell: UITableViewCell {

    
    
    @IBOutlet weak var LNA: UILabel!
    
    
    @IBOutlet weak var LHM: UILabel!
    

}
